import math

# -----------------------------
# Input values
# -----------------------------
Q = 2.5                 # design flow [m3/s]

# Penstock dimensions
L_penstock = 543.0      # pipe length [m]
D_penstock = 0.95       # pipe diameter [m]
lambda_f = 0.015        # Darcy-Weisbach friction factor [-]

# Tunnel loss coefficient
k_tunnel = 0.244        # [s^2/m^5]

# Constants
g = 9.81                # gravitational acceleration [m/s^2]

# -----------------------------
# Penstock loss coefficient
# -----------------------------
A_penstock = math.pi * D_penstock**2 / 4

k_penstock = (
    lambda_f
    * (L_penstock / D_penstock)
    * (1 / (2 * g * A_penstock**2))
)

# -----------------------------
# Total loss coefficient
# -----------------------------
k_total = k_tunnel + k_penstock

# -----------------------------
# Head losses
# -----------------------------
h_tunnel = k_tunnel * Q**2
h_penstock = k_penstock * Q**2
h_total = k_total * Q**2

# -----------------------------
# Print results
# -----------------------------
print("PENSTOCK AND TUNNEL LOSS COEFFICIENT")
print("------------------------------------")
print(f"Design flow: {Q:.2f} m3/s")
print(f"Penstock length: {L_penstock:.1f} m")
print(f"Penstock diameter: {D_penstock:.3f} m")
print(f"Friction factor lambda: {lambda_f:.3f}")
print(f"Penstock area: {A_penstock:.3f} m2")
print()
print(f"Tunnel loss coefficient: {k_tunnel:.3f} s2/m5")
print(f"Penstock loss coefficient: {k_penstock:.3f} s2/m5")
print(f"Total loss coefficient: {k_total:.3f} s2/m5")
print()
print(f"Tunnel head loss: {h_tunnel:.2f} m")
print(f"Penstock head loss: {h_penstock:.2f} m")
print(f"Total head loss: {h_total:.2f} m")