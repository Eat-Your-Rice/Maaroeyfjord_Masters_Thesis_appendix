bin_path <- "C:/nMag2004_Meraker/nMag2004_Meraker/4.4MW_SC0.bin"
binf <- file(bin_path, "rb")

bin_name <- basename(bin_path)
bin_stem <- tools::file_path_sans_ext(bin_name)
output_dir <- dirname(bin_path)

plot_dir <- file.path(output_dir, paste0(bin_stem, "_plots"))
dir.create(plot_dir, showWarnings = FALSE)

pdf_file <- file.path(output_dir, paste0(bin_stem, ".pdf"))
saved_plots <- list()

save_current_plot <- function(plot_name) {
  safe_name <- gsub("[^A-Za-z0-9_\\-]", "_", plot_name)
  current_plot <- recordPlot()
  
  saved_plots[[length(saved_plots) + 1]] <<- current_plot
  
  png(
    file.path(plot_dir, paste0(safe_name, ".png")),
    width = 1800,
    height = 1200,
    res = 200
  )
  
  replayPlot(current_plot)
  dev.off()
}

# -----------------------------
# READ HEADER BLOCKS
# -----------------------------
lblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")

nfelt <- (lblk - 20) / 40
per   <- (nblk - 5) / nfelt
aar   <- (nblk - 5) / 365
verd  <- lblk / 4

staar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slaar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum    <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nper   <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
stper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
parsim <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 9), endian = "little")

dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nfelt2 <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nibyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nrbyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum21  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 6), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

qm <- NULL
for (i in 1:nfelt2) {
  qm[i] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
}
dumval <- readBin(binf, integer(), size = 4, n = (verd - nfelt2), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

# -----------------------------
# READ MAIN DATA
# -----------------------------
nmres <- matrix(data = NA, ncol = (nfelt * 10 + 5), nrow = (aar * 365))

for (i in 1:(aar * 365)) {
  nmres[i, 1] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 2] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 3] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 4] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 5] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  
  for (j in 1:nfelt) {
    nmres[i,  5 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  6 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  7 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  8 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  9 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 10 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 11 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 12 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 13 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 14 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  }
}

close(binf)

# -----------------------------
# CREATE DATA FRAME
# -----------------------------
u <- data.frame(nmres)
u <- transform(u, RDate = as.Date(X2 - 1, origin = paste(as.character(X1), "-01-01", sep = "")))

names(u)[1:5] <- c("YEAR", "PER", "FKPER", "PSUM", "COST")

for (j in 1:nfelt) {
  names(u)[ 5 + (j - 1) * 10 + 1] <- paste0("STOR_",   j)
  names(u)[ 6 + (j - 1) * 10 + 1] <- paste0("WLEV_",   j)
  names(u)[ 7 + (j - 1) * 10 + 1] <- paste0("INFLOW_", j)
  names(u)[ 8 + (j - 1) * 10 + 1] <- paste0("Q_",      j)
  names(u)[ 9 + (j - 1) * 10 + 1] <- paste0("THRUF_",  j)
  names(u)[10 + (j - 1) * 10 + 1] <- paste0("BYPASS_", j)
  names(u)[11 + (j - 1) * 10 + 1] <- paste0("SPILL_",  j)
  names(u)[12 + (j - 1) * 10 + 1] <- paste0("PROD_",   j)
  names(u)[13 + (j - 1) * 10 + 1] <- paste0("DUM1_",   j)
  names(u)[14 + (j - 1) * 10 + 1] <- paste0("DUM2_",   j)
}

# -----------------------------
# PREPARE TIME VARIABLES
# -----------------------------
u$DOY <- as.numeric(format(u$RDate, "%j"))

years  <- sort(unique(u$YEAR))
nyears <- length(years)

first_years <- years[1:5]
mid_start   <- floor(nyears / 2) - 2
mid_years   <- years[mid_start:(mid_start + 4)]
last_years  <- tail(years, 5)

# -----------------------------
# TOTAL SPILL STATISTICS
# -----------------------------
sec_per_day <- 86400

total_spill_res1 <- sum(u$SPILL_1, na.rm = TRUE)
total_spill_res3 <- sum(u$SPILL_3, na.rm = TRUE)

total_spill_res1_Mm3 <- total_spill_res1 * sec_per_day / 1e6
total_spill_res3_Mm3 <- total_spill_res3 * sec_per_day / 1e6

cat("\n-----------------------------\n")
cat("TOTAL SPILL (Million m3)\n")
cat("-----------------------------\n")
cat("Reservoir 1:", round(total_spill_res1_Mm3, 2), "Mm3\n")
cat("Reservoir 3:", round(total_spill_res3_Mm3, 2), "Mm3\n")

# -----------------------------
# YEARLY WATER CALCULATIONS
# -----------------------------
seconds_per_day <- 86400

results <- data.frame(
  YEAR = years,
  Spill_Res1_Mm3 = NA,
  Spill_Res3_Mm3 = NA,
  Throughflow_Res1_Mm3 = NA,
  Total_Outflow_Res1_Mm3 = NA,
  Ratio_THRUF_to_Q = NA
)

for (i in seq_along(years)) {
  y   <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  spill1 <- sum(dfy$SPILL_1, na.rm = TRUE) * seconds_per_day
  spill3 <- sum(dfy$SPILL_3, na.rm = TRUE) * seconds_per_day
  thruf1 <- sum(dfy$THRUF_1, na.rm = TRUE) * seconds_per_day
  Q1     <- sum(dfy$Q_1, na.rm = TRUE) * seconds_per_day
  
  results$Spill_Res1_Mm3[i] <- spill1 / 1e6
  results$Spill_Res3_Mm3[i] <- spill3 / 1e6
  results$Throughflow_Res1_Mm3[i] <- thruf1 / 1e6
  results$Total_Outflow_Res1_Mm3[i] <- Q1 / 1e6
  results$Ratio_THRUF_to_Q[i] <- ifelse(Q1 > 0, thruf1 / Q1, NA)
}

# -----------------------------
# FUNCTIONS
# -----------------------------
compute_means <- function(df, var, years_subset = NULL) {
  if (!is.null(years_subset)) {
    df <- df[df$YEAR %in% years_subset, ]
  }
  aggregate(df[[var]], by = list(DOY = df$DOY), FUN = mean, na.rm = TRUE)
}

year_to_plot <- 2020
params <- c("WLEV", "INFLOW", "Q", "THRUF", "PROD", "SPILL")

plot_param <- function(res_id, res_name, var_base) {
  var <- paste0(var_base, "_", res_id)
  
  if (!var %in% names(u)) {
    warning(paste("Column not found:", var))
    return()
  }
  
  flow_vars <- c("INFLOW", "Q", "THRUF", "SPILL", "BYPASS")
  
  all_mean   <- compute_means(u, var)
  first_mean <- compute_means(u, var, first_years)
  mid_mean   <- compute_means(u, var, mid_years)
  last_mean  <- compute_means(u, var, last_years)
  
  df_year <- u[u$YEAR == year_to_plot, ]
  df_year <- df_year[order(df_year$DOY), ]
  
  if (nrow(df_year) == 0) {
    warning(paste("Year", year_to_plot, "not found in data"))
    return()
  }
  
  y_all <- c(all_mean$x, first_mean$x, mid_mean$x, last_mean$x, df_year[[var]])
  y_all <- y_all[is.finite(y_all)]
  
  if (length(y_all) == 0) {
    warning(paste("No finite values for", var))
    return()
  }
  
  if (var_base %in% flow_vars) {
    ymax <- max(y_all, na.rm = TRUE)
    if (!is.finite(ymax) || ymax <= 0) ymax <- 1
    ylim_range <- c(0, ymax * 1.05)
  } else {
    ylim_range <- range(y_all, na.rm = TRUE)
    if (diff(ylim_range) == 0) {
      ylim_range <- ylim_range + c(-1, 1)
    }
  }
  
  y_label <- switch(
    var_base,
    "INFLOW" = expression("Flow (" * m^3 / s * ")"),
    "Q"      = expression("Flow (" * m^3 / s * ")"),
    "THRUF"  = expression("Flow (" * m^3 / s * ")"),
    "SPILL"  = expression("Flow (" * m^3 / s * ")"),
    "BYPASS" = expression("Flow (" * m^3 / s * ")"),
    "WLEV"   = "Water level (masl)",
    "STOR"   = expression("Storage (Mm"^3 * ")"),
    "PROD"   = "Production (MW)",
    var_base
  )
  
  plot(
    all_mean$DOY, all_mean$x,
    type = "l",
    lwd = 2,
    col = "black",
    ylim = ylim_range,
    xlab = "Day of Year",
    ylab = y_label,
    main = paste(bin_name, "|", res_name, "-", var_base)
  )
  
  lines(first_mean$DOY, first_mean$x, col = "blue", lty = 2)
  lines(mid_mean$DOY, mid_mean$x, col = "green", lty = 2)
  lines(last_mean$DOY, last_mean$x, col = "red", lty = 2)
  lines(df_year$DOY, df_year[[var]], col = "orange", lwd = 2)
  
  legend(
    "right",
    legend = c("All years (mean)", "First 5", "Middle 5", "Last 5", paste("Year", year_to_plot)),
    col = c("black", "blue", "green", "red", "orange"),
    lty = c(1, 2, 2, 2, 1),
    lwd = c(2, 1, 1, 1, 2)
  )
  
  save_current_plot(paste(res_name, var_base, sep = "_"))
}

# -----------------------------
# PLOTTING
# -----------------------------
par(mgp = c(2, 0.7, 0))

for (p in params) {
  plot_param(1, "Reinkalvvatn", p)
}

for (p in params) {
  plot_param(3, "Reinoksvatn", p)
}

# -----------------------------
# ANNUAL SIMULATED POWER PRODUCTION
# -----------------------------
annual_production <- data.frame(
  YEAR = years,
  PROD_1_GWh = NA,
  PROD_3_GWh = NA,
  TOTAL_PROD_GWh = NA
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  prod1_GWh <- sum(dfy$PROD_1, na.rm = TRUE) * 24 / 1000
  prod3_GWh <- sum(dfy$PROD_3, na.rm = TRUE) * 24 / 1000
  
  annual_production$PROD_1_GWh[i] <- prod1_GWh
  annual_production$PROD_3_GWh[i] <- prod3_GWh
  annual_production$TOTAL_PROD_GWh[i] <- prod1_GWh + prod3_GWh
}

avg_prod <- mean(annual_production$TOTAL_PROD_GWh, na.rm = TRUE)

# -----------------------------
# IMPORT REAL PRODUCTION DATA 2013-2021
# -----------------------------
real_data_folder <- "C:/nMag2004_Meraker/nMag2004_Meraker"
real_years <- 2013:2021

real_hourly <- data.frame()

for (y in real_years) {
  csv_path <- file.path(real_data_folder, paste0(y, ".csv"))
  
  if (!file.exists(csv_path)) {
    warning(paste("CSV file not found:", csv_path))
    next
  }
  
  temp <- read.csv(csv_path, sep = ";", header = TRUE, fileEncoding = "UTF-8-BOM")
  
  names(temp) <- trimws(names(temp))
  
  temp$DATE <- as.Date(temp$Dato, format = "%d.%m.%Y")
  temp$YEAR <- as.numeric(format(temp$DATE, "%Y"))
  temp$DOY  <- as.numeric(format(temp$DATE, "%j"))
  temp$Production_MWh <- as.numeric(temp$Mengde.MWh)
  
  real_hourly <- rbind(
    real_hourly,
    temp[, c("YEAR", "DATE", "DOY", "Time", "Production_MWh")]
  )
}

# -----------------------------
# DAILY REAL PRODUCTION
# -----------------------------
real_daily <- aggregate(
  real_hourly$Production_MWh,
  by = list(
    YEAR = real_hourly$YEAR,
    DATE = real_hourly$DATE,
    DOY = real_hourly$DOY
  ),
  FUN = sum,
  na.rm = TRUE
)

names(real_daily)[4] <- "Daily_MWh"
real_daily$Daily_MW <- real_daily$Daily_MWh / 24

# -----------------------------
# ANNUAL REAL PRODUCTION
# -----------------------------
real_annual <- aggregate(
  real_daily$Daily_MWh,
  by = list(YEAR = real_daily$YEAR),
  FUN = sum,
  na.rm = TRUE
)

names(real_annual)[2] <- "Real_Production_MWh"
real_annual$Real_Production_GWh <- real_annual$Real_Production_MWh / 1000

cat("\n================ REAL ANNUAL PRODUCTION ================\n")
print(real_annual)

# -----------------------------
# ANNUAL PRODUCTION COMPARISON
# -----------------------------
real_comparison_years <- c(2013:2015, 2017:2021)
sim_comparison_years <- 2013:2021

real_annual_plot <- real_annual[
  real_annual$YEAR %in% real_comparison_years,
]

sim_annual_plot <- annual_production[
  annual_production$YEAR %in% sim_comparison_years,
]

avg_prod_plot <- mean(sim_annual_plot$TOTAL_PROD_GWh, na.rm = TRUE)

plot(
  sim_annual_plot$YEAR,
  sim_annual_plot$TOTAL_PROD_GWh,
  type = "b",
  pch = 16,
  lwd = 2,
  xlab = "Year",
  ylab = "Annual production (GWh/year)",
  main = paste(bin_name, "| Annual production comparison, 2013-2021 excl. 2016"),
  ylim = c(0, 35)
)

lines(
  real_annual_plot$YEAR,
  real_annual_plot$Real_Production_GWh,
  type = "b",
  pch = 17,
  lwd = 2,
  col = "blue"
)

abline(h = avg_prod_plot, col = "red", lwd = 2, lty = 2)

legend(
  "bottom",
  legend = c(
    "Simulated annual production",
    "Measured annual production (excl 2016)",
    "Simulated average"
  ),
  col = c("black", "blue", "red"),
  lty = c(1, 1, 2),
  lwd = c(2, 2, 2),
  pch = c(16, 17, NA)
)

save_current_plot("Annual_production_comparison")

# -----------------------------
# DAILY PRODUCTION COMPARISON
# -----------------------------

# Simulated mean daily production, full simulation period
sim_mean_daily <- aggregate(
  u$PROD_1,
  by = list(DOY = u$DOY),
  FUN = mean,
  na.rm = TRUE
)

names(sim_mean_daily)[2] <- "Sim_Mean_Daily_Full"

# Simulated mean daily production, 2013-2021 incl. 2016
sim_daily_2013_2021 <- u[u$YEAR %in% 2013:2021, ]

sim_mean_daily_2013_2021 <- aggregate(
  sim_daily_2013_2021$PROD_1,
  by = list(DOY = sim_daily_2013_2021$DOY),
  FUN = mean,
  na.rm = TRUE
)

names(sim_mean_daily_2013_2021)[2] <- "Sim_Mean_Daily_2013_2021"

# Measured mean daily production, 2013-2021 excl. 2016
measured_years <- c(2013:2015, 2017:2021)

real_daily_plot <- real_daily[real_daily$YEAR %in% measured_years, ]

real_mean_daily <- aggregate(
  real_daily_plot$Daily_MW,
  by = list(DOY = real_daily_plot$DOY),
  FUN = mean,
  na.rm = TRUE
)

names(real_mean_daily)[2] <- "Mean_Daily_MW"

plot(
  sim_mean_daily$DOY,
  sim_mean_daily$Sim_Mean_Daily_Full,
  type = "l",
  lwd = 2,
  col = "red",
  lty = 2,
  ylim = c(1.5, 4.2),
  xlab = "Day of year",
  ylab = "Daily average power production (MW)",
  main = paste(bin_name, "| Daily production comparison")
)

lines(
  sim_mean_daily_2013_2021$DOY,
  sim_mean_daily_2013_2021$Sim_Mean_Daily_2013_2021,
  col = "darkgreen",
  lwd = 2,
  lty = 3
)

lines(
  real_mean_daily$DOY,
  real_mean_daily$Mean_Daily_MW,
  col = "blue",
  lwd = 2
)

legend(
  "bottom",
  legend = c(
    "Simulated mean daily production (full period)",
    "Simulated mean daily production (2013-2021 incl. 2016)",
    "Measured mean daily production (2013-2021 excl. 2016)"
  ),
  col = c("red", "darkgreen", "blue"),
  lty = c(2, 3, 1),
  lwd = c(2, 2, 2),
  cex = 0.75
)

save_current_plot("Daily_production_comparison")

# -----------------------------
# NSE AND CORRELATION
# -----------------------------
comparison <- merge(
  sim_mean_daily,
  real_mean_daily,
  by = "DOY"
)

obs <- comparison$Mean_Daily_MW
sim <- comparison$Sim_Mean_Daily_Full

obs <- comparison$Mean_Daily_MW
sim <- comparison$Sim_Mean_Daily_Full

nse <- 1 - sum((obs - sim)^2) / sum((obs - mean(obs))^2)

correlation <- cor(
  comparison$Sim_Mean_Daily_Full,
  comparison$Mean_Daily_MW,
  use = "complete.obs"
)

cat("\n================ DAILY COMPARISON METRICS ================\n")
cat(sprintf("NSE: %.3f\n", nse))
cat(sprintf("Correlation: %.3f\n", correlation))

# -----------------------------
# PRODUCTION COMPARISON SUMMARY
# -----------------------------
real_avg_full_period <- 29.80

real_avg_2013_2021_excl_2016 <- mean(
  real_annual$Real_Production_GWh[
    real_annual$YEAR %in% real_comparison_years
  ],
  na.rm = TRUE
)

sim_avg_2013_2021 <- mean(
  annual_production$TOTAL_PROD_GWh[
    annual_production$YEAR %in% sim_comparison_years
  ],
  na.rm = TRUE
)

sim_avg_full_period <- mean(
  annual_production$TOTAL_PROD_GWh,
  na.rm = TRUE
)

deviation_gwh_2013_2021 <- sim_avg_2013_2021 - real_avg_2013_2021_excl_2016
deviation_pct_2013_2021 <- 100 * deviation_gwh_2013_2021 / real_avg_2013_2021_excl_2016

deviation_gwh_full <- sim_avg_full_period - real_avg_full_period
deviation_pct_full <- 100 * deviation_gwh_full / real_avg_full_period

production_summary <- data.frame(
  Period = c(
    "Full period 1991-2021",
    "Full period 1991-2021",
    "Full period 1991-2021",
    "Full period 1991-2021",
    "2013-2021",
    "2013-2021 excl. 2016",
    "2013-2021 comparison",
    "2013-2021 comparison"
  ),
  Metric = c(
    "Measured average production",
    "Simulated average production",
    "Deviation simulated vs measured",
    "Deviation simulated vs measured",
    "Simulated average production",
    "Measured average production",
    "Deviation simulated vs measured",
    "Deviation simulated vs measured"
  ),
  Value = c(
    real_avg_full_period,
    sim_avg_full_period,
    deviation_gwh_full,
    deviation_pct_full,
    sim_avg_2013_2021,
    real_avg_2013_2021_excl_2016,
    deviation_gwh_2013_2021,
    deviation_pct_2013_2021
  ),
  Unit = c(
    "GWh/year",
    "GWh/year",
    "GWh/year",
    "%",
    "GWh/year",
    "GWh/year",
    "GWh/year",
    "%"
  )
)

cat("\n================ PRODUCTION COMPARISON SUMMARY ================\n")
print(production_summary, row.names = FALSE)

cat("\n================ WATER RESULTS ================\n")
cat("\nAVERAGES:\n")
cat(sprintf("Avg Spill Res1: %.2f Mm3/year\n", mean(results$Spill_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Spill Res3: %.2f Mm3/year\n", mean(results$Spill_Res3_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Throughflow Res1: %.2f Mm3/year\n", mean(results$Throughflow_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Total Outflow Res1: %.2f Mm3/year\n", mean(results$Total_Outflow_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg THRUF/Q Ratio (Res1): %.3f\n", mean(results$Ratio_THRUF_to_Q, na.rm = TRUE)))

# -----------------------------
# CREATE PDF CONTAINING ALL PLOTS
# -----------------------------
pdf(pdf_file, width = 11, height = 8)

for (p in saved_plots) {
  replayPlot(p)
}

dev.off()

# -----------------------------
# EXPORT CSV FILES
# -----------------------------
write.csv(
  u,
  file = file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")),
  row.names = FALSE
)

write.csv(
  results,
  file = file.path(output_dir, paste0(bin_stem, "_water_results.csv")),
  row.names = FALSE
)

write.csv(
  annual_production,
  file = file.path(output_dir, paste0(bin_stem, "_annual_production.csv")),
  row.names = FALSE
)

write.csv(
  production_summary,
  file = file.path(output_dir, paste0(bin_stem, "_production_summary.csv")),
  row.names = FALSE
)

write.csv(
  comparison,
  file = file.path(output_dir, paste0(bin_stem, "_daily_comparison.csv")),
  row.names = FALSE
)

cat("\n================ EXPORT COMPLETE ================\n")
cat("Files written to:\n")
cat(file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_water_results.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_annual_production.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_production_summary.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_daily_comparison.csv")), "\n")
cat(pdf_file, "\n")
cat("PNG plots written to:\n")
cat(plot_dir, "\n")