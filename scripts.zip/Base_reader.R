bin_path <- "C:/nMag2004_Meraker/nMag2004_Meraker/4.4MW_SC0.bin"
binf <- file(bin_path, "rb")
bin_name <- basename(bin_path)
bin_stem <- tools::file_path_sans_ext(bin_name)
output_dir <- dirname(bin_path)

plot_dir <- file.path(output_dir, paste0(bin_stem, "_plots"))
dir.create(plot_dir, showWarnings = FALSE)

pdf_file <- file.path(output_dir, paste0(bin_stem, ".pdf"))
saved_plots <- list()

save_current_plot <- function(plot_name) {
  safe_name <- gsub("[^A-Za-z0-9_\\-]", "_", plot_name)
  current_plot <- recordPlot()
  
  saved_plots[[length(saved_plots) + 1]] <<- current_plot
  
  png(
    file.path(plot_dir, paste0(safe_name, ".png")),
    width = 1800,
    height = 1200,
    res = 200
  )
  
  replayPlot(current_plot)
  dev.off()
}

# -----------------------------
# READ HEADER BLOCKS
# -----------------------------
lblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")

nfelt <- (lblk - 20) / 40
per   <- (nblk - 5) / nfelt
aar   <- (nblk - 5) / 365
verd  <- lblk / 4

staar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slaar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum    <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nper   <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
stper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
parsim <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 9), endian = "little")

dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nfelt2 <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nibyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nrbyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum21  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 6), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

qm <- NULL
for (i in 1:nfelt2) {
  qm[i] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
}
dumval <- readBin(binf, integer(), size = 4, n = (verd - nfelt2), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

# -----------------------------
# READ MAIN DATA
# -----------------------------
nmres <- matrix(data = NA, ncol = (nfelt * 10 + 5), nrow = (aar * 365))

for (i in 1:(aar * 365)) {
  nmres[i, 1] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 2] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 3] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 4] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 5] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  
  for (j in 1:nfelt) {
    nmres[i,  5 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  6 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  7 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  8 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  9 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 10 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 11 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 12 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 13 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 14 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  }
}

close(binf)

# -----------------------------
# CREATE DATA FRAME
# -----------------------------
u <- data.frame(nmres)
u <- transform(u, RDate = as.Date(X2 - 1, origin = paste(as.character(X1), "-01-01", sep = "")))

names(u)[1:5] <- c("YEAR", "PER", "FKPER", "PSUM", "COST")

for (j in 1:nfelt) {
  names(u)[ 5 + (j - 1) * 10 + 1] <- paste0("STOR_",   j)
  names(u)[ 6 + (j - 1) * 10 + 1] <- paste0("WLEV_",   j)
  names(u)[ 7 + (j - 1) * 10 + 1] <- paste0("INFLOW_", j)
  names(u)[ 8 + (j - 1) * 10 + 1] <- paste0("Q_",      j)
  names(u)[ 9 + (j - 1) * 10 + 1] <- paste0("THRUF_",  j)
  names(u)[10 + (j - 1) * 10 + 1] <- paste0("BYPASS_", j)
  names(u)[11 + (j - 1) * 10 + 1] <- paste0("SPILL_",  j)
  names(u)[12 + (j - 1) * 10 + 1] <- paste0("PROD_",   j)
  names(u)[13 + (j - 1) * 10 + 1] <- paste0("DUM1_",   j)
  names(u)[14 + (j - 1) * 10 + 1] <- paste0("DUM2_",   j)
}

# -----------------------------
# PREPARE TIME VARIABLES
# -----------------------------
u$DOY <- as.numeric(format(u$RDate, "%j"))

years  <- sort(unique(u$YEAR))
nyears <- length(years)

first_years <- years[1:5]
mid_start   <- floor(nyears / 2) - 2
mid_years   <- years[mid_start:(mid_start + 4)]
last_years  <- tail(years, 5)

# -----------------------------
# TOTAL SPILL STATISTICS
# -----------------------------
sec_per_day <- 86400

total_spill_res1 <- sum(u$SPILL_1, na.rm = TRUE)
total_spill_res3 <- sum(u$SPILL_3, na.rm = TRUE)

total_spill_res1_Mm3 <- total_spill_res1 * sec_per_day / 1e6
total_spill_res3_Mm3 <- total_spill_res3 * sec_per_day / 1e6

cat("\n-----------------------------\n")
cat("TOTAL SPILL (Million m3)\n")
cat("-----------------------------\n")
cat("Reservoir 1:", round(total_spill_res1_Mm3, 2), "Mm3\n")
cat("Reservoir 3:", round(total_spill_res3_Mm3, 2), "Mm3\n")

# -----------------------------
# YEARLY WATER CALCULATIONS
# -----------------------------
seconds_per_day <- 86400

results <- data.frame(
  YEAR = years,
  Spill_Res1_Mm3 = NA,
  Spill_Res3_Mm3 = NA,
  Throughflow_Res1_Mm3 = NA,
  Total_Outflow_Res1_Mm3 = NA,
  Ratio_THRUF_to_Q = NA
)

for (i in seq_along(years)) {
  y   <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  spill1 <- sum(dfy$SPILL_1, na.rm = TRUE) * seconds_per_day
  spill3 <- sum(dfy$SPILL_3, na.rm = TRUE) * seconds_per_day
  thruf1 <- sum(dfy$THRUF_1, na.rm = TRUE) * seconds_per_day
  Q1     <- sum(dfy$Q_1, na.rm = TRUE) * seconds_per_day
  
  results$Spill_Res1_Mm3[i] <- spill1 / 1e6
  results$Spill_Res3_Mm3[i] <- spill3 / 1e6
  results$Throughflow_Res1_Mm3[i] <- thruf1 / 1e6
  results$Total_Outflow_Res1_Mm3[i] <- Q1 / 1e6
  results$Ratio_THRUF_to_Q[i] <- ifelse(Q1 > 0, thruf1 / Q1, NA)
}

# -----------------------------
# FUNCTIONS
# -----------------------------
compute_means <- function(df, var, years_subset = NULL) {
  if (!is.null(years_subset)) {
    df <- df[df$YEAR %in% years_subset, ]
  }
  aggregate(df[[var]], by = list(DOY = df$DOY), FUN = mean, na.rm = TRUE)
}

year_to_plot <- 2020
params <- c("WLEV", "INFLOW", "Q", "THRUF", "PROD", "SPILL")

plot_param <- function(res_id, res_name, var_base) {
  var <- paste0(var_base, "_", res_id)
  
  if (!var %in% names(u)) {
    warning(paste("Column not found:", var))
    return()
  }
  
  flow_vars <- c("INFLOW", "Q", "THRUF", "SPILL", "BYPASS")
  
  all_mean   <- compute_means(u, var)
  first_mean <- compute_means(u, var, first_years)
  mid_mean   <- compute_means(u, var, mid_years)
  last_mean  <- compute_means(u, var, last_years)
  
  df_year <- u[u$YEAR == year_to_plot, ]
  df_year <- df_year[order(df_year$DOY), ]
  
  if (nrow(df_year) == 0) {
    warning(paste("Year", year_to_plot, "not found in data"))
    return()
  }
  
  y_all <- c(all_mean$x, first_mean$x, mid_mean$x, last_mean$x, df_year[[var]])
  y_all <- y_all[is.finite(y_all)]
  
  if (length(y_all) == 0) {
    warning(paste("No finite values for", var))
    return()
  }
  
  if (var_base %in% flow_vars) {
    ymax <- max(y_all, na.rm = TRUE)
    if (!is.finite(ymax) || ymax <= 0) ymax <- 1
    ylim_range <- c(0, ymax * 1.05)
  } else {
    ylim_range <- range(y_all, na.rm = TRUE)
    if (diff(ylim_range) == 0) {
      ylim_range <- ylim_range + c(-1, 1)
    }
  }
  
  y_label <- switch(
    var_base,
    "INFLOW" = expression("Flow (" * m^3 / s * ")"),
    "Q"      = expression("Flow (" * m^3 / s * ")"),
    "THRUF"  = expression("Flow (" * m^3 / s * ")"),
    "SPILL"  = expression("Flow (" * m^3 / s * ")"),
    "BYPASS" = expression("Flow (" * m^3 / s * ")"),
    "WLEV"   = "Water level (masl)",
    "STOR"   = expression("Storage (Mm"^3 * ")"),
    "PROD"   = "Production (MW)",
    var_base
  )
  
  plot(
    all_mean$DOY, all_mean$x,
    type = "l",
    lwd = 2,
    col = "black",
    ylim = ylim_range,
    xlab = "Day of Year",
    ylab = y_label,
    main = paste(bin_name, "|", res_name, "-", var_base)
  )
  
  lines(first_mean$DOY, first_mean$x, col = "blue", lty = 2)
  lines(mid_mean$DOY, mid_mean$x, col = "green", lty = 2)
  lines(last_mean$DOY, last_mean$x, col = "red", lty = 2)
  lines(df_year$DOY, df_year[[var]], col = "orange", lwd = 2)
  
  legend(
    "bottomleft",
    legend = c("All years (mean)", "First 5", "Middle 5", "Last 5", paste("Year", year_to_plot)),
    col = c("black", "blue", "green", "red", "orange"),
    lty = c(1, 2, 2, 2, 1),
    lwd = c(2, 1, 1, 1, 2)
  )
  
  save_current_plot(paste(res_name, var_base, sep = "_"))
}

# -----------------------------
# PLOTTING
# -----------------------------
par(mgp = c(2, 0.7, 0))

for (p in params) {
  plot_param(1, "Fossvatn", p)
}

for (p in params) {
  plot_param(3, "Reinoksvatn", p)
}

# -----------------------------
# ANNUAL POWER PRODUCTION PLOT
# -----------------------------
annual_production <- data.frame(
  YEAR = years,
  PROD_1_GWh = NA,
  PROD_3_GWh = NA,
  TOTAL_PROD_GWh = NA
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  prod1_GWh <- sum(dfy$PROD_1, na.rm = TRUE) * 24 / 1000
  prod3_GWh <- sum(dfy$PROD_3, na.rm = TRUE) * 24 / 1000
  
  annual_production$PROD_1_GWh[i] <- prod1_GWh
  annual_production$PROD_3_GWh[i] <- prod3_GWh
  annual_production$TOTAL_PROD_GWh[i] <- prod1_GWh + prod3_GWh
}

avg_prod <- mean(annual_production$TOTAL_PROD_GWh, na.rm = TRUE)

cat("\n================ ANNUAL POWER PRODUCTION ================\n")
print(annual_production)
cat(sprintf("\nAverage annual production: %.2f GWh/year\n", avg_prod))

plot(
  annual_production$YEAR,
  annual_production$TOTAL_PROD_GWh,
  type = "b",
  pch = 16,
  lwd = 2,
  xlab = "Year",
  ylab = "Annual production (GWh/year)",
  main = paste(bin_name, "| Total annual power production")
)

abline(h = avg_prod, col = "red", lwd = 2, lty = 2)

legend(
  "topright",
  legend = c(
    "Annual production",
    "Average",
    paste0(round(avg_prod, 2), " GWh/year")
  ),
  col = c("black", "red", NA),
  lty = c(1, 2, NA),
  lwd = c(2, 2, NA),
  pch = c(16, NA, NA),
  bty = "n"
)
save_current_plot("Total_annual_power_production")
# -----------------------------
# RESERVOIR ENERGY STORAGE AVAILABILITY
# -----------------------------
energy_threshold_kWh <- 1632054
energy_equivalent <- 0.489

water_threshold_m3 <- energy_threshold_kWh / energy_equivalent
water_threshold_Mm3 <- water_threshold_m3 / 1e6

cat("\n-----------------------------\n")
cat("RESERVOIR STORAGE THRESHOLD\n")
cat("-----------------------------\n")
cat(sprintf("Energy threshold: %.0f kWh\n", energy_threshold_kWh))
cat(sprintf("Energy equivalent: %.3f kWh/m3\n", energy_equivalent))
cat(sprintf("Required water volume: %.2f m3\n", water_threshold_m3))
cat(sprintf("Required water volume: %.3f Mm3\n", water_threshold_Mm3))

u$Combined_Storage_Mm3 <- u$STOR_1 + u$STOR_3

storage_availability <- data.frame(
  YEAR = years,
  Days_Above_Threshold = NA,
  Percent_Above_Threshold = NA
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  days_above <- sum(dfy$Combined_Storage_Mm3 >= water_threshold_Mm3, na.rm = TRUE)
  total_days <- nrow(dfy)
  
  storage_availability$Days_Above_Threshold[i] <- days_above
  storage_availability$Percent_Above_Threshold[i] <- 100 * days_above / total_days
}

cat("\n================ STORAGE AVAILABILITY ================\n")
print(storage_availability)

cat(sprintf("\nAverage time above threshold: %.1f %%\n",
            mean(storage_availability$Percent_Above_Threshold, na.rm = TRUE)))

plot(
  storage_availability$YEAR,
  storage_availability$Percent_Above_Threshold,
  type = "b",
  pch = 16,
  lwd = 2,
  xlab = "Year",
  ylab = "Time above threshold (%)",
  main = paste(bin_name, "| Reservoir storage above required energy threshold"),
  ylim = c(0, 100)
)

abline(
  h = mean(storage_availability$Percent_Above_Threshold, na.rm = TRUE),
  col = "red",
  lwd = 2,
  lty = 2
)

avg_storage_security <- mean(
  storage_availability$Percent_Above_Threshold,
  na.rm = TRUE
)

legend(
  "bottomright",
  legend = c(
    "Yearly value",
    paste0("Energy security = ",
           round(avg_storage_security, 1),
           " %")
  ),
  
  col = c("black", "red"),
  lty = c(1, 2),
  lwd = c(2, 2),
  pch = c(16, NA),
  bty = "n"
)
save_current_plot("Reservoir_storage_above_threshold")

# -----------------------------
# PRINT RESULTS
# -----------------------------
cat("\n================ WATER RESULTS ================\n")

cat("\nAVERAGES:\n")
cat(sprintf("Avg Spill Res1: %.2f Mm3/year\n", mean(results$Spill_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Spill Res3: %.2f Mm3/year\n", mean(results$Spill_Res3_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Throughflow Res1: %.2f Mm3/year\n", mean(results$Throughflow_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg Total Outflow Res1: %.2f Mm3/year\n", mean(results$Total_Outflow_Res1_Mm3, na.rm = TRUE)))
cat(sprintf("Avg THRUF/Q Ratio (Res1): %.3f\n", mean(results$Ratio_THRUF_to_Q, na.rm = TRUE)))

# -----------------------------
# CREATE PDF CONTAINING ALL PLOTS
# -----------------------------
pdf(pdf_file, width = 11, height = 8)

for (p in saved_plots) {
  replayPlot(p)
}

dev.off()

# -----------------------------
# EXPORT CSV FILES
# -----------------------------
write.csv(
  u,
  file = file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")),
  row.names = FALSE
)

write.csv(
  results,
  file = file.path(output_dir, paste0(bin_stem, "_water_results.csv")),
  row.names = FALSE
)

write.csv(
  annual_production,
  file = file.path(output_dir, paste0(bin_stem, "_annual_production.csv")),
  row.names = FALSE
)

write.csv(
  storage_availability,
  file = file.path(output_dir, paste0(bin_stem, "_storage_availability.csv")),
  row.names = FALSE
)

cat("\n================ EXPORT COMPLETE ================\n")
cat("Files written to:\n")
cat(file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_water_results.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_annual_production.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_storage_availability.csv")), "\n")
cat(pdf_file, "\n")
cat("PNG plots written to:\n")
cat(plot_dir, "\n")