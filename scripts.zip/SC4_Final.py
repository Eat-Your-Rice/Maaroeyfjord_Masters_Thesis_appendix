import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ============================================================
# SCENARIO INPUTS
# ============================================================

scenarios = {
    "8.5MW_SC4B": {
        "Q": 2.5,                # design flow [m3/s]
        "H": 295,               # gross head [m]
        "eta": 0.91,              # total efficiency [-]
        "price": 0.6789,          # NOK/kWh
        "operating_hours": 5483   # hours/year
    },

    "8MW_SC4D": {
        "Q": 2.5,                # design flow [m3/s]
        "H": 290,               # gross head [m]
        "eta": 0.91,              # total efficiency [-]
        "price": 0.6810,          # NOK/kWh
        "operating_hours":5496    # hours/year
    }
}

# ============================================================
# COMMON INPUT DATA
# ============================================================

# Tunnel data
L_tunnel = 3500.0        # tunnel length [m]
M_blasted = 33           # Manning coefficient for blasted tunnel [m^(1/3)/s]
M_drilled = 65           # Manning coefficient for drilled tunnel [m^(1/3)/s]

# Penstock data
L_penstock = 543.0       # penstock length [m]
lambda_f = 0.015         # Darcy-Weisbach friction factor [-]

# Constants
rho = 1000               # water density [kg/m3]
g = 9.81                 # gravitational acceleration [m/s2]

# Economic data
n = 40                   # analysis period [years]
r = 0.06                 # discount rate [-]
Escalation_factor = 1.615

# Diameter / area ranges
A_blasted_range = np.linspace(18, 22, 300)       # blasted tunnel cross-section range [m2]
D_drilled_mm_range = np.linspace(800, 3000, 300) # drilled tunnel diameter range [mm]
D_penstock_range = np.linspace(0.5, 1.6, 300)    # penstock diameter range [m]

# Present value factor
PV_factor = (1 - (1 + r) ** (-n)) / r

# ============================================================
# RUN ALL SCENARIOS
# ============================================================

for run_name, scenario in scenarios.items():

    output_dir = Path(run_name)
    output_dir.mkdir(exist_ok=True)

    file_prefix = run_name

    Q = scenario["Q"]
    H = scenario["H"]
    eta = scenario["eta"]
    price = scenario["price"]
    operating_hours = scenario["operating_hours"]

    # ========================================================
    # 1) BLASTED TUNNEL OPTIMIZATION
    # ========================================================

    A_blasted = A_blasted_range.copy()

    side_blasted = np.sqrt(A_blasted)
    O_blasted = 4 * side_blasted
    R_blasted = A_blasted / O_blasted

    velocity_blasted = Q / A_blasted

    h_tunnel_blasted = (
        L_tunnel * Q**2
        / (M_blasted**2 * A_blasted**2 * R_blasted**(4 / 3))
    )

    k_tunnel_blasted = h_tunnel_blasted / Q**2

    E_loss_tunnel_blasted = (
        rho * g * Q * h_tunnel_blasted * eta * operating_hours * 3600
        / 3.6e6
    )

    PV_loss_tunnel_blasted = E_loss_tunnel_blasted * price * PV_factor

    tunnel_cost_per_m_blasted = (
        1.68 * A_blasted**3
        - 105 * A_blasted**2
        + 2654.5 * A_blasted
        - 8055.6
    )

    tunnel_cost_blasted_base = tunnel_cost_per_m_blasted * L_tunnel
    tunnel_cost_blasted = tunnel_cost_blasted_base * Escalation_factor

    marginal_cost_blasted = np.gradient(tunnel_cost_blasted, A_blasted)
    marginal_value_blasted = -np.gradient(PV_loss_tunnel_blasted, A_blasted)

    difference_blasted = np.abs(marginal_cost_blasted - marginal_value_blasted)
    idx_opt_blasted = np.argmin(difference_blasted)

    A_opt_blasted = A_blasted[idx_opt_blasted]
    side_opt_blasted = side_blasted[idx_opt_blasted]
    O_opt_blasted = O_blasted[idx_opt_blasted]
    R_opt_blasted = R_blasted[idx_opt_blasted]
    velocity_opt_blasted = velocity_blasted[idx_opt_blasted]
    h_tunnel_opt_blasted = h_tunnel_blasted[idx_opt_blasted]
    k_tunnel_opt_blasted = k_tunnel_blasted[idx_opt_blasted]
    tunnel_cost_opt_blasted = tunnel_cost_blasted[idx_opt_blasted]
    PV_loss_opt_tunnel_blasted = PV_loss_tunnel_blasted[idx_opt_blasted]

    # ========================================================
    # 2) DRILLED TUNNEL OPTIMIZATION
    # ========================================================

    D_drilled_mm = D_drilled_mm_range.copy()
    D_drilled = D_drilled_mm / 1000

    A_drilled = np.pi * D_drilled**2 / 4
    O_drilled = np.pi * D_drilled
    R_drilled = A_drilled / O_drilled

    velocity_drilled = Q / A_drilled

    h_tunnel_drilled = (
        L_tunnel * Q**2
        / (M_drilled**2 * A_drilled**2 * R_drilled**(4 / 3))
    )

    k_tunnel_drilled = h_tunnel_drilled / Q**2

    E_loss_tunnel_drilled = (
        rho * g * Q * h_tunnel_drilled * eta * operating_hours * 3600
        / 3.6e6
    )

    PV_loss_tunnel_drilled = E_loss_tunnel_drilled * price * PV_factor

    tunnel_cost_per_m_drilled = (
        ((18000 - 11000) / (1350 - 700))
        * D_drilled_mm
        + 3460
    )

    tunnel_cost_drilled_base = tunnel_cost_per_m_drilled * L_tunnel
    tunnel_cost_drilled = tunnel_cost_drilled_base * Escalation_factor * 2

    marginal_cost_drilled = np.gradient(tunnel_cost_drilled, D_drilled)
    marginal_value_drilled = -np.gradient(PV_loss_tunnel_drilled, D_drilled)

    difference_drilled = np.abs(marginal_cost_drilled - marginal_value_drilled)
    idx_opt_drilled = np.argmin(difference_drilled)

    D_opt_drilled = D_drilled[idx_opt_drilled]
    D_opt_drilled_mm = D_drilled_mm[idx_opt_drilled]
    A_opt_drilled = A_drilled[idx_opt_drilled]
    O_opt_drilled = O_drilled[idx_opt_drilled]
    R_opt_drilled = R_drilled[idx_opt_drilled]
    velocity_opt_drilled = velocity_drilled[idx_opt_drilled]
    h_tunnel_opt_drilled = h_tunnel_drilled[idx_opt_drilled]
    k_tunnel_opt_drilled = k_tunnel_drilled[idx_opt_drilled]
    tunnel_cost_opt_drilled = tunnel_cost_drilled[idx_opt_drilled]
    PV_loss_opt_tunnel_drilled = PV_loss_tunnel_drilled[idx_opt_drilled]

    # ========================================================
    # 3) PENSTOCK OPTIMIZATION
    # ========================================================

    D_penstock = D_penstock_range.copy()
    D_penstock_mm = D_penstock * 1000

    A_penstock = np.pi * D_penstock**2 / 4
    C_penstock = Q / A_penstock

    k_penstock = (
        lambda_f
        * (L_penstock / D_penstock)
        * (1 / (2 * g * A_penstock**2))
    )

    h_penstock = k_penstock * Q**2

    E_loss_penstock = (
        rho * g * Q * h_penstock * eta * operating_hours * 3600
        / 3.6e6
    )

    PV_loss_penstock = E_loss_penstock * price * PV_factor

    pipe_cost_per_m = 825.1 * np.exp(0.0019 * D_penstock_mm) * 1.5

    foundation_cost_per_m = (
        0.0006 * D_penstock_mm**2
        + 2.6118 * D_penstock_mm
        + 2030
    )

    total_cost_per_m = pipe_cost_per_m + foundation_cost_per_m

    pipe_cost_2015 = total_cost_per_m * L_penstock
    pipe_cost = pipe_cost_2015 * Escalation_factor * 2

    marginal_pipe_cost = np.gradient(pipe_cost, D_penstock)
    marginal_loss_value_penstock = -np.gradient(PV_loss_penstock, D_penstock)

    difference_penstock = np.abs(marginal_pipe_cost - marginal_loss_value_penstock)
    idx_opt_penstock = np.argmin(difference_penstock)

    D_opt_penstock = D_penstock[idx_opt_penstock]
    D_opt_penstock_mm = D_penstock_mm[idx_opt_penstock]
    A_opt_penstock = A_penstock[idx_opt_penstock]
    velocity_opt_penstock = C_penstock[idx_opt_penstock]
    k_penstock_opt = k_penstock[idx_opt_penstock]
    h_penstock_opt = h_penstock[idx_opt_penstock]
    pipe_cost_opt = pipe_cost[idx_opt_penstock]
    PV_loss_opt_penstock = PV_loss_penstock[idx_opt_penstock]

    # ========================================================
    # 4) COMBINED SYSTEM RESULTS
    # ========================================================

    # Blasted tunnel + optimal penstock
    k_total_blasted = k_tunnel_opt_blasted + k_penstock_opt
    h_total_blasted = h_tunnel_opt_blasted + h_penstock_opt
    H_net_blasted = H - h_total_blasted
    P_MW_blasted = rho * g * Q * H_net_blasted * eta / 1e6

    E_loss_total_blasted = (
        rho * g * Q * h_total_blasted * eta * operating_hours * 3600
        / 3.6e6
    )

    PV_loss_total_blasted = E_loss_total_blasted * price * PV_factor

    investment_total_blasted = tunnel_cost_opt_blasted + pipe_cost_opt

    # Drilled tunnel + optimal penstock
    k_total_drilled = k_tunnel_opt_drilled + k_penstock_opt
    h_total_drilled = h_tunnel_opt_drilled + h_penstock_opt
    H_net_drilled = H - h_total_drilled
    P_MW_drilled = rho * g * Q * H_net_drilled * eta / 1e6

    E_loss_total_drilled = (
        rho * g * Q * h_total_drilled * eta * operating_hours * 3600
        / 3.6e6
    )

    PV_loss_total_drilled = E_loss_total_drilled * price * PV_factor

    investment_total_drilled = tunnel_cost_opt_drilled + pipe_cost_opt

    # ========================================================
    # 5) SUMMARY TABLES
    # ========================================================

    summary_table = pd.DataFrame({
        "Alternative": [
            "Blasted tunnel + optimal penstock",
            "Drilled tunnel + optimal penstock"
        ],

        "Design flow [m3/s]": [
            Q,
            Q
        ],

        "Gross head [m]": [
            H,
            H
        ],

        "Efficiency [-]": [
            eta,
            eta
        ],

        "Electricity price [NOK/kWh]": [
            price,
            price
        ],

        "Operating hours [h/year]": [
            operating_hours,
            operating_hours
        ],

        "Tunnel type": [
            "Blasted",
            "Drilled"
        ],

        "Optimal tunnel dimension": [
            A_opt_blasted,
            D_opt_drilled
        ],

        "Tunnel dimension unit": [
            "m2",
            "m"
        ],

        "Optimal tunnel cross-section [m2]": [
            A_opt_blasted,
            A_opt_drilled
        ],

        "Optimal tunnel diameter [m]": [
            np.nan,
            D_opt_drilled
        ],

        "Optimal blasted tunnel side length [m]": [
            side_opt_blasted,
            np.nan
        ],

        "Tunnel velocity at optimum [m/s]": [
            velocity_opt_blasted,
            velocity_opt_drilled
        ],

        "Tunnel hydraulic radius at optimum [m]": [
            R_opt_blasted,
            R_opt_drilled
        ],

        "Tunnel loss coefficient [s2/m5]": [
            k_tunnel_opt_blasted,
            k_tunnel_opt_drilled
        ],

        "Tunnel head loss [m]": [
            h_tunnel_opt_blasted,
            h_tunnel_opt_drilled
        ],

        "Optimal penstock diameter [m]": [
            D_opt_penstock,
            D_opt_penstock
        ],

        "Optimal penstock diameter [mm]": [
            D_opt_penstock_mm,
            D_opt_penstock_mm
        ],

        "Penstock area at optimum [m2]": [
            A_opt_penstock,
            A_opt_penstock
        ],

        "Penstock velocity at optimum [m/s]": [
            velocity_opt_penstock,
            velocity_opt_penstock
        ],

        "Penstock loss coefficient [s2/m5]": [
            k_penstock_opt,
            k_penstock_opt
        ],

        "Penstock head loss [m]": [
            h_penstock_opt,
            h_penstock_opt
        ],

        "Total loss coefficient [s2/m5]": [
            k_total_blasted,
            k_total_drilled
        ],

        "Total head loss [m]": [
            h_total_blasted,
            h_total_drilled
        ],

        "Net head [m]": [
            H_net_blasted,
            H_net_drilled
        ],

        "Power output [MW]": [
            P_MW_blasted,
            P_MW_drilled
        ],

        "Annual energy loss [GWh/year]": [
            E_loss_total_blasted / 1e6,
            E_loss_total_drilled / 1e6
        ],

        "PV of friction losses [MNOK]": [
            PV_loss_total_blasted / 1e6,
            PV_loss_total_drilled / 1e6
        ],

        "Tunnel cost [MNOK]": [
            tunnel_cost_opt_blasted / 1e6,
            tunnel_cost_opt_drilled / 1e6
        ],

        "Penstock cost [MNOK]": [
            pipe_cost_opt / 1e6,
            pipe_cost_opt / 1e6
        ],

        "Total tunnel + penstock cost [MNOK]": [
            investment_total_blasted / 1e6,
            investment_total_drilled / 1e6
        ]
    })

    input_table = pd.DataFrame({
        "Parameter": [
            "Run name",
            "Design flow rate",
            "Tunnel length",
            "Penstock length",
            "Gross head",
            "Total efficiency",
            "Water density",
            "Gravitational acceleration",
            "Manning coefficient blasted tunnel",
            "Manning coefficient drilled tunnel",
            "Darcy-Weisbach friction factor",
            "Electricity price",
            "Analysis period",
            "Discount rate",
            "Operating hours",
            "Cost escalation factor",
            "Blasted tunnel area range minimum",
            "Blasted tunnel area range maximum",
            "Drilled tunnel diameter range minimum",
            "Drilled tunnel diameter range maximum",
            "Penstock diameter range minimum",
            "Penstock diameter range maximum"
        ],
        "Symbol": [
            "run_name",
            "Q",
            "L_tunnel",
            "L_penstock",
            "H",
            "eta",
            "rho",
            "g",
            "M_blasted",
            "M_drilled",
            "lambda_f",
            "price",
            "n",
            "r",
            "operating_hours",
            "Escalation_factor",
            "A_blasted_min",
            "A_blasted_max",
            "D_drilled_min",
            "D_drilled_max",
            "D_penstock_min",
            "D_penstock_max"
        ],
        "Value": [
            run_name,
            Q,
            L_tunnel,
            L_penstock,
            H,
            eta,
            rho,
            g,
            M_blasted,
            M_drilled,
            lambda_f,
            price,
            n,
            r,
            operating_hours,
            Escalation_factor,
            A_blasted_range.min(),
            A_blasted_range.max(),
            D_drilled_mm_range.min() / 1000,
            D_drilled_mm_range.max() / 1000,
            D_penstock_range.min(),
            D_penstock_range.max()
        ],
        "Unit": [
            "-",
            "m3/s",
            "m",
            "m",
            "m",
            "-",
            "kg/m3",
            "m/s2",
            "m^(1/3)/s",
            "m^(1/3)/s",
            "-",
            "NOK/kWh",
            "years",
            "-",
            "hours/year",
            "-",
            "m2",
            "m2",
            "m",
            "m",
            "m",
            "m"
        ]
    })

    # ========================================================
    # 6) EXPORT CSV AND EXCEL
    # ========================================================

    summary_csv = output_dir / f"{file_prefix}_combined_tunnel_penstock_summary.csv"
    summary_xlsx = output_dir / f"{file_prefix}_combined_tunnel_penstock_summary.xlsx"

    summary_table.to_csv(summary_csv, index=False)

    with pd.ExcelWriter(summary_xlsx) as writer:
        input_table.to_excel(writer, sheet_name="Inputs", index=False)
        summary_table.to_excel(writer, sheet_name="Summary", index=False)

    # ========================================================
    # 7) PLOTS
    # ========================================================

    plt.figure(figsize=(9, 6))
    plt.plot(A_blasted, marginal_cost_blasted / 1e6, label="Marginal tunnel cost")
    plt.plot(A_blasted, marginal_value_blasted / 1e6, label="Marginal value of reduced head loss")
    plt.axvline(
        A_opt_blasted,
        linestyle="--",
        label=f"Optimal area ≈ {A_opt_blasted:.2f} m²"
    )

    plt.xlabel("Tunnel cross section [m²]")
    plt.ylabel("Marginal value [MNOK per m² increase]")
    plt.title(f"{run_name}: Economic optimization of blasted tunnel cross section")
    plt.xlim(A_blasted.min(), A_blasted.max())
    plt.legend()
    plt.grid(True)

    blasted_png = output_dir / f"{file_prefix}_blasted_tunnel_optimization.png"
    plt.savefig(blasted_png, dpi=300, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(9, 6))
    plt.plot(D_drilled, marginal_cost_drilled / 1e6, label="Marginal drilled tunnel cost")
    plt.plot(D_drilled, marginal_value_drilled / 1e6, label="Marginal value of reduced head loss")
    plt.axvline(
        D_opt_drilled,
        linestyle="--",
        label=f"Optimal diameter ≈ {D_opt_drilled:.2f} m"
    )

    plt.xlabel("Drilled tunnel diameter [m]")
    plt.ylabel("Marginal value [MNOK per m diameter increase]")
    plt.title(f"{run_name}: Economic optimization of drilled tunnel diameter")
    plt.xlim(D_drilled.min(), D_drilled.max())
    plt.ylim(0, 300)
    plt.legend()
    plt.grid(True)

    drilled_png = output_dir / f"{file_prefix}_drilled_tunnel_optimization.png"
    plt.savefig(drilled_png, dpi=300, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(9, 6))
    plt.plot(D_penstock, marginal_pipe_cost / 1e6, label="Marginal pipe cost")
    plt.plot(D_penstock, marginal_loss_value_penstock / 1e6, label="Marginal value of reduced head loss")
    plt.axvline(
        D_opt_penstock,
        linestyle="--",
        label=f"Optimal diameter ≈ {D_opt_penstock:.2f} m"
    )

    plt.xlabel("Penstock diameter [m]")
    plt.ylabel("Marginal value [MNOK per m diameter increase]")
    plt.title(f"{run_name}: Economic optimization of penstock diameter")
    plt.xlim(D_penstock.min(), D_penstock.max())
    plt.ylim(0, 300)
    plt.legend()
    plt.grid(True)

    penstock_png = output_dir / f"{file_prefix}_penstock_optimization.png"
    plt.savefig(penstock_png, dpi=300, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(9, 6))

    alternatives = ["Blasted", "Drilled"]
    tunnel_losses = [h_tunnel_opt_blasted, h_tunnel_opt_drilled]
    penstock_losses = [h_penstock_opt, h_penstock_opt]

    x = np.arange(len(alternatives))

    plt.bar(x, tunnel_losses, label="Tunnel head loss")
    plt.bar(x, penstock_losses, bottom=tunnel_losses, label="Penstock head loss")

    plt.xticks(x, alternatives)
    plt.ylabel("Head loss [m]")
    plt.title(f"{run_name}: Combined tunnel and penstock head losses")
    plt.legend()
    plt.grid(axis="y")

    head_loss_png = output_dir / f"{file_prefix}_combined_head_losses.png"
    plt.savefig(head_loss_png, dpi=300, bbox_inches="tight")
    plt.close()

    # ========================================================
    # 8) PRINT RESULTS
    # ========================================================

    print("\n====================================================")
    print(f"RUN COMPLETE: {run_name}")
    print("====================================================")

    print("\n--- Optimal penstock ---")
    print(f"Optimal penstock diameter: {D_opt_penstock:.3f} m")
    print(f"Penstock velocity at optimum: {velocity_opt_penstock:.2f} m/s")
    print(f"Penstock loss coefficient: {k_penstock_opt:.3f} s2/m5")
    print(f"Penstock head loss: {h_penstock_opt:.2f} m")
    print(f"Penstock cost: {pipe_cost_opt / 1e6:.2f} MNOK")

    print("\n--- Blasted tunnel option ---")
    print(f"Optimal blasted tunnel area: {A_opt_blasted:.2f} m2")
    print(f"Tunnel head loss: {h_tunnel_opt_blasted:.2f} m")
    print(f"Total head loss: {h_total_blasted:.2f} m")
    print(f"Total loss coefficient: {k_total_blasted:.3f} s2/m5")
    print(f"Net head: {H_net_blasted:.2f} m")
    print(f"Power output: {P_MW_blasted:.2f} MW")

    print("\n--- Drilled tunnel option ---")
    print(f"Optimal drilled tunnel diameter: {D_opt_drilled:.3f} m")
    print(f"Tunnel head loss: {h_tunnel_opt_drilled:.2f} m")
    print(f"Total head loss: {h_total_drilled:.2f} m")
    print(f"Total loss coefficient: {k_total_drilled:.3f} s2/m5")
    print(f"Net head: {H_net_drilled:.2f} m")
    print(f"Power output: {P_MW_drilled:.2f} MW")

    print("\nFiles exported to:")
    print(output_dir.resolve())