import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ============================================================
# FILE NAMING / OUTPUT FOLDER
# ============================================================

run_name = "4.4MW_SC1"

output_dir = Path(run_name)
output_dir.mkdir(exist_ok=True)

file_prefix = run_name
# ============================================================
# INPUT DATA
# ============================================================

Q = 2.5                # designed flow [m3/s]
L_penstock = 543.0       # penstock length [m]
H = 225.3               # gross head [m]
eta = 0.87              # efficiency [-]
rho = 1000               # water density [kg/m3]
g = 9.81                 # gravity [m/s2]
lambda_f = 0.015         # Darcy-Weisbach friction factor [-]

k_tunnel = 0.244         # tunnel loss coefficient [s2/m5]

price = 0.6298         # NOK/kWh
n = 40                   # analysis period [years]
r = 0.06                 # discount rate [-]
operating_hours = 6792    # hours/year

Escalation_factor = 1.615

D = np.linspace(0.5, 1.6, 300)   # diameter range [m]
D_mm = D * 1000


# ============================================================
# HYDRAULIC CALCULATIONS
# ============================================================

A = np.pi * D**2 / 4
C = Q / A

k_penstock = lambda_f * (L_penstock / D) * (1 / (2 * g * A**2))
k_total = k_tunnel + k_penstock

h_penstock = k_penstock * Q**2
h_tunnel = k_tunnel * Q**2
h_total = k_total * Q**2

H_net = H - h_total

P_MW = rho * g * Q * H_net * eta / 1e6

E_loss = rho * g * Q * h_total * eta * operating_hours * 3600 / 3.6e6

PV_factor = (1 - (1 + r)**(-n)) / r
PV_loss = E_loss * price * PV_factor

# ============================================================
# COST CALCULATIONS
# ============================================================

pipe_cost_per_m = 825.1 * np.exp(0.0019 * D_mm) * 1.5

foundation_cost_per_m = (
    0.0006 * D_mm**2
    + 2.6118 * D_mm
    + 2030
)

total_cost_per_m = pipe_cost_per_m + foundation_cost_per_m

pipe_cost_2015 = total_cost_per_m * L_penstock
pipe_cost = pipe_cost_2015 * Escalation_factor * 2

# ============================================================
# ECONOMIC OPTIMIZATION
# ============================================================

marginal_pipe_cost = np.gradient(pipe_cost, D)
marginal_loss_value = -np.gradient(PV_loss, D)

difference = np.abs(marginal_pipe_cost - marginal_loss_value)
idx_opt = np.argmin(difference)

D_opt = D[idx_opt]

# ============================================================
# SUMMARY TABLE
# ============================================================

summary_table = pd.DataFrame({
    "Category": [
        "Input", "Input", "Input", "Input", "Input", "Input", "Input",
        "Input", "Input", "Input", "Input", "Input", "Input",
        "Input", "Input", "Input",
        "Result", "Result", "Result", "Result", "Result", "Result",
        "Result", "Result", "Result", "Result"
    ],
    "Parameter": [
        "Design flow rate",
        "Penstock length",
        "Gross head",
        "Total efficiency",
        "Water density",
        "Gravitational acceleration",
        "Darcy-Weisbach friction factor",
        "Tunnel loss coefficient",
        "Electricity price",
        "Analysis period",
        "Discount rate",
        "Operating hours",
        "Diameter range minimum",
        "Diameter range maximum",
        "Number of diameter steps",
        "Cost escalation factor",
        "Optimal diameter",
        "Velocity at optimum",
        "Penstock loss coefficient at optimum",
        "Tunnel loss coefficient",
        "Total loss coefficient at optimum",
        "Penstock head loss at optimum",
        "Tunnel head loss at design flow",
        "Total head loss at optimum",
        "Pipe cost at optimum",
        "PV of friction losses at optimum"
    ],
    "Symbol": [
        "Q", "L", "H", "eta", "rho", "g", "lambda_f",
        "k_tunnel", "price", "n", "r", "operating_hours",
        "D_min", "D_max", "D_steps", "Escalation_factor",
        "D_opt", "C_opt", "k_penstock_opt", "k_tunnel",
        "k_total_opt", "h_penstock_opt", "h_tunnel",
        "h_total_opt", "pipe_cost_opt", "PV_loss_opt"
    ],
    "Value": [
        Q,
        L_penstock,
        H,
        eta,
        rho,
        g,
        lambda_f,
        k_tunnel,
        price,
        n,
        r,
        operating_hours,
        D.min(),
        D.max(),
        len(D),
        Escalation_factor,
        D_opt,
        C[idx_opt],
        k_penstock[idx_opt],
        k_tunnel,
        k_total[idx_opt],
        h_penstock[idx_opt],
        h_tunnel,
        h_total[idx_opt],
        pipe_cost[idx_opt] / 1e6,
        PV_loss[idx_opt] / 1e6
    ],
    "Unit": [
        "m3/s", "m", "m", "-", "kg/m3", "m/s2", "-",
        "s2/m5", "NOK/kWh", "years", "-", "hours/year",
        "m", "m", "-", "-",
        "m", "m/s", "s2/m5", "s2/m5",
        "s2/m5", "m", "m", "m", "MNOK", "MNOK"
    ]
})

# ============================================================
# EXPORT CSV AND EXCEL
# ============================================================

summary_csv = output_dir / f"{file_prefix}_penstock_optimization_results.csv"
summary_xlsx = output_dir / f"{file_prefix}_penstock_optimization_results.xlsx"

summary_table.to_csv(summary_csv, index=False)

with pd.ExcelWriter(summary_xlsx) as writer:
    summary_table.to_excel(writer, sheet_name="Summary", index=False)

# ============================================================
# PLOT 1: ECONOMIC OPTIMIZATION
# ============================================================

plt.figure()
plt.plot(D, marginal_pipe_cost / 1e6, label="Marginal pipe cost")
plt.plot(D, marginal_loss_value / 1e6, label="Marginal value of reduced head loss")
plt.axvline(D_opt, linestyle="--", label=f"Optimal diameter ≈ {D_opt:.2f} m")

plt.xlabel("Pipe diameter [m]")
plt.ylabel("Marginal value [MNOK per m diameter increase]")
plt.title(f"{run_name}: Economic optimization of penstock diameter")
plt.xlim(0.5, 1.5)
plt.ylim(0, 300)
plt.legend()
plt.grid(True)

marginal_png = output_dir / f"{file_prefix}_penstock_optimization_marginal_curves.png"
plt.savefig(marginal_png, dpi=300, bbox_inches="tight")
plt.show()

# ============================================================
# PRINT RESULTS
# ============================================================

print("\n================ OPTIMIZATION RESULTS ================")
print(f"Run name: {run_name}")
print(f"Optimal diameter: {D_opt:.3f} m")
print(f"Velocity at optimum: {C[idx_opt]:.2f} m/s")
print(f"Penstock loss coefficient at optimum: {k_penstock[idx_opt]:.3f} s2/m5")
print(f"Tunnel loss coefficient: {k_tunnel:.3f} s2/m5")
print(f"Total loss coefficient at optimum: {k_total[idx_opt]:.3f} s2/m5")
print(f"Penstock head loss at optimum: {h_penstock[idx_opt]:.2f} m")
print(f"Tunnel head loss at design flow: {h_tunnel:.2f} m")
print(f"Total head loss at optimum: {h_total[idx_opt]:.2f} m")
print(f"Net head at optimum: {H_net[idx_opt]:.2f} m")
print(f"Power at optimum: {P_MW[idx_opt]:.2f} MW")
print(f"Annual energy loss at optimum: {E_loss[idx_opt] / 1e6:.2f} GWh/year")
print(f"Pipe cost at optimum: {pipe_cost[idx_opt] / 1e6:.2f} MNOK")
print(f"PV of friction losses at optimum: {PV_loss[idx_opt] / 1e6:.2f} MNOK")

print("\nFiles exported to folder:")
print(output_dir.resolve())
print(summary_csv.name)
print(summary_xlsx.name)
print(marginal_png.name)