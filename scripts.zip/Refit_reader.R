bin_path <- "C:/nMag2004_Meraker/nMag2004_Meraker/8.5MW_SC4B.bin"
binf <- file(bin_path, "rb")
bin_name <- basename(bin_path)

output_dir <- dirname(bin_path)
bin_stem <- tools::file_path_sans_ext(bin_name)

plot_dir <- file.path(output_dir, paste0(bin_stem, "_plots"))
dir.create(plot_dir, showWarnings = FALSE)

pdf_file <- file.path(output_dir, paste0(bin_stem, ".pdf"))
saved_plots <- list()

save_current_plot <- function(plot_name) {
  safe_name <- gsub("[^A-Za-z0-9_\\-]", "_", plot_name)
  png_file <- file.path(plot_dir, paste0(safe_name, ".png"))
  
  current_plot <- recordPlot()
  saved_plots[[length(saved_plots) + 1]] <<- current_plot
  
  png(png_file, width = 1800, height = 1200, res = 200)
  replayPlot(current_plot)
  dev.off()
}

# -----------------------------
# MODULE SETUP
# -----------------------------
fossvatn_res_id      <- 5
fossvatn_plant_id    <- 1
reinoksvatn_res_id   <- 3
reinoksvatn_plant_id <- 4
ocean_id             <- 2

# -----------------------------
# READ HEADER BLOCKS
# -----------------------------
lblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nblk <- readBin(binf, integer(), size = 4, n = 1, endian = "little")

nfelt <- (lblk - 20) / 40
per   <- (nblk - 5) / nfelt
aar   <- (nblk - 5) / 365
verd  <- lblk / 4

staar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slaar  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum    <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nper   <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
stper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
slper  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
parsim <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 9), endian = "little")

dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nfelt2 <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumvar <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nibyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
nrbyt  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dum21  <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
dumval <- readBin(binf, integer(), size = 4, n = (verd - 6), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

qm <- NULL
for (i in 1:nfelt2) {
  qm[i] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
}
dumval <- readBin(binf, integer(), size = 4, n = (verd - nfelt2), endian = "little")

dumval <- readBin(binf, integer(), size = 4, n = verd, endian = "little")

# -----------------------------
# READ MAIN DATA
# -----------------------------
nmres <- matrix(data = NA, ncol = (nfelt * 10 + 5), nrow = (aar * 365))

for (i in 1:(aar * 365)) {
  nmres[i, 1] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 2] <- readBin(binf, integer(), size = 4, n = 1, endian = "little")
  nmres[i, 3] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 4] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  nmres[i, 5] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  
  for (j in 1:nfelt) {
    nmres[i,  5 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  6 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  7 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  8 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i,  9 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 10 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 11 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 12 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 13 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
    nmres[i, 14 + (j - 1) * 10 + 1] <- readBin(binf, numeric(), size = 4, n = 1, endian = "little")
  }
}

close(binf)

# -----------------------------
# CREATE DATA FRAME
# -----------------------------
u <- data.frame(nmres)
u <- transform(u, RDate = as.Date(X2 - 1, origin = paste(as.character(X1), "-01-01", sep = "")))

names(u)[1:5] <- c("YEAR", "PER", "FKPER", "PSUM", "COST")

for (j in 1:nfelt) {
  names(u)[ 5 + (j - 1) * 10 + 1] <- paste0("STOR_",   j)
  names(u)[ 6 + (j - 1) * 10 + 1] <- paste0("WLEV_",   j)
  names(u)[ 7 + (j - 1) * 10 + 1] <- paste0("INFLOW_", j)
  names(u)[ 8 + (j - 1) * 10 + 1] <- paste0("Q_",      j)
  names(u)[ 9 + (j - 1) * 10 + 1] <- paste0("THRUF_",  j)
  names(u)[10 + (j - 1) * 10 + 1] <- paste0("BYPASS_", j)
  names(u)[11 + (j - 1) * 10 + 1] <- paste0("SPILL_",  j)
  names(u)[12 + (j - 1) * 10 + 1] <- paste0("PROD_",   j)
  names(u)[13 + (j - 1) * 10 + 1] <- paste0("DUM1_",   j)
  names(u)[14 + (j - 1) * 10 + 1] <- paste0("DUM2_",   j)
}

# -----------------------------
# TIME VARIABLES
# -----------------------------
u$DOY <- as.numeric(format(u$RDate, "%j"))

years  <- sort(unique(u$YEAR))
nyears <- length(years)

first_years <- years[1:5]
mid_start   <- floor(nyears / 2) - 2
mid_years   <- years[mid_start:(mid_start + 4)]
last_years  <- tail(years, 5)

seconds_per_day <- 86400

# -----------------------------
# YEARLY WATER RESULTS
# -----------------------------
results <- data.frame(
  YEAR = years,
  Throughflow_Fossvatn_PowerPlant_Mm3 = NA_real_,
  Throughflow_Reinoksvatn_PowerPlant_Mm3 = NA_real_,
  Total_Outflow_Fossvatn_PowerPlant_Mm3 = NA_real_,
  Total_Outflow_Reinoksvatn_PowerPlant_Mm3 = NA_real_
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  thruf_foss_plant <- sum(dfy[[paste0("THRUF_", fossvatn_plant_id)]], na.rm = TRUE) * seconds_per_day / 1e6
  thruf_rein_plant <- sum(dfy[[paste0("THRUF_", reinoksvatn_plant_id)]], na.rm = TRUE) * seconds_per_day / 1e6
  
  q_foss_plant <- sum(dfy[[paste0("Q_", fossvatn_plant_id)]], na.rm = TRUE) * seconds_per_day / 1e6
  q_rein_plant <- sum(dfy[[paste0("Q_", reinoksvatn_plant_id)]], na.rm = TRUE) * seconds_per_day / 1e6
  
  results$Throughflow_Fossvatn_PowerPlant_Mm3[i] <- thruf_foss_plant
  results$Throughflow_Reinoksvatn_PowerPlant_Mm3[i] <- thruf_rein_plant
  results$Total_Outflow_Fossvatn_PowerPlant_Mm3[i] <- q_foss_plant
  results$Total_Outflow_Reinoksvatn_PowerPlant_Mm3[i] <- q_rein_plant
}

cat("\n================ WATER RESULTS ================\n")
print(results)

cat("\nAVERAGE WATER FLOW:\n")
cat(sprintf("Average throughflow Fossvatn power plant: %.2f Mm3/year\n",
            mean(results$Throughflow_Fossvatn_PowerPlant_Mm3, na.rm = TRUE)))
cat(sprintf("Average throughflow Reinoksvatn power plant: %.2f Mm3/year\n",
            mean(results$Throughflow_Reinoksvatn_PowerPlant_Mm3, na.rm = TRUE)))
cat(sprintf("Average total outflow Fossvatn power plant: %.2f Mm3/year\n",
            mean(results$Total_Outflow_Fossvatn_PowerPlant_Mm3, na.rm = TRUE)))
cat(sprintf("Average total outflow Reinoksvatn power plant: %.2f Mm3/year\n",
            mean(results$Total_Outflow_Reinoksvatn_PowerPlant_Mm3, na.rm = TRUE)))

# -----------------------------
# ANNUAL PRODUCTION BY RESERVOIR / WATERWAY
# -----------------------------
annual_production <- data.frame(
  YEAR = years,
  Fossvatn_GWh = NA_real_,
  Reinoksvatn_GWh = NA_real_,
  Total_GWh = NA_real_
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  foss_prod <- sum(dfy[[paste0("PROD_", fossvatn_plant_id)]], na.rm = TRUE) * 24 / 1000
  rein_prod <- sum(dfy[[paste0("PROD_", reinoksvatn_plant_id)]], na.rm = TRUE) * 24 / 1000
  
  annual_production$Fossvatn_GWh[i] <- foss_prod
  annual_production$Reinoksvatn_GWh[i] <- rein_prod
  annual_production$Total_GWh[i] <- foss_prod + rein_prod
}

cat("\n================ PRODUCTION BY RESERVOIR ================\n")
print(annual_production)

cat("\nAVERAGE PRODUCTION:\n")
cat(sprintf("Average Fossvatn production: %.2f GWh/year\n",
            mean(annual_production$Fossvatn_GWh, na.rm = TRUE)))
cat(sprintf("Average Reinoksvatn production: %.2f GWh/year\n",
            mean(annual_production$Reinoksvatn_GWh, na.rm = TRUE)))
cat(sprintf("Average total production: %.2f GWh/year\n",
            mean(annual_production$Total_GWh, na.rm = TRUE)))

# -----------------------------
# FUNCTIONS
# -----------------------------
compute_means <- function(df, var, years_subset = NULL) {
  if (!var %in% names(df)) {
    stop(paste("Column not found:", var))
  }
  
  if (!is.null(years_subset)) {
    df <- df[df$YEAR %in% years_subset, ]
  }
  
  aggregate(df[[var]], by = list(DOY = df$DOY), FUN = mean, na.rm = TRUE)
}

year_to_plot <- 2020

plot_param <- function(module_id, module_name, var_base, inflow_source_id = module_id) {
  source_id <- if (var_base == "INFLOW") inflow_source_id else module_id
  var <- paste0(var_base, "_", source_id)
  
  if (!var %in% names(u)) {
    warning(paste("Column", var, "not found. Skipping plot."))
    return()
  }
  
  flow_vars <- c("INFLOW", "Q", "THRUF", "BYPASS")
  
  all_mean   <- compute_means(u, var)
  first_mean <- compute_means(u, var, first_years)
  mid_mean   <- compute_means(u, var, mid_years)
  last_mean  <- compute_means(u, var, last_years)
  
  df_year <- u[u$YEAR == year_to_plot, ]
  df_year <- df_year[order(df_year$DOY), ]
  
  y_all <- c(all_mean$x, first_mean$x, mid_mean$x, last_mean$x)
  
  if (nrow(df_year) > 0) {
    y_all <- c(y_all, df_year[[var]])
  }
  
  y_all <- y_all[is.finite(y_all)]
  
  if (length(y_all) == 0) {
    warning(paste("No finite values for", var))
    return()
  }
  
  if (var_base %in% flow_vars) {
    ymax <- max(y_all, na.rm = TRUE)
    if (!is.finite(ymax) || ymax <= 0) ymax <- 1
    ylim_range <- c(0, ymax * 1.05)
  } else {
    ylim_range <- range(y_all, na.rm = TRUE)
    if (diff(ylim_range) == 0) {
      ylim_range <- ylim_range + c(-1, 1)
    }
  }
  
  y_label <- switch(
    var_base,
    "INFLOW" = expression("Flow (" * m^3 / s * ")"),
    "Q"      = expression("Flow (" * m^3 / s * ")"),
    "THRUF"  = expression("Flow (" * m^3 / s * ")"),
    "BYPASS" = expression("Bypass (" * m^3 / s * ")"),
    "WLEV"   = "Water level (m a.s.l.)",
    "STOR"   = expression("Reservoir storage (Mm"^3 * ")"),
    "PROD"   = "Power production (MW)",
    var_base
  )
  
  plot(
    all_mean$DOY, all_mean$x,
    type = "l",
    lwd = 2,
    col = "black",
    ylim = ylim_range,
    xlab = "Day of year",
    ylab = y_label,
    main = paste(bin_name, "|", module_name, "-", var_base)
  )
  
  lines(first_mean$DOY, first_mean$x, col = "blue",  lty = 2)
  lines(mid_mean$DOY,   mid_mean$x,   col = "green", lty = 2)
  lines(last_mean$DOY,  last_mean$x,  col = "red",   lty = 2)
  
  if (nrow(df_year) > 0) {
    lines(df_year$DOY, df_year[[var]], col = "orange", lwd = 2)
  }
  
  legend(
    "bottomright",
    legend = c("All years mean", "First 5 years", "Middle 5 years", "Last 5 years",
               paste("Year", year_to_plot)),
    col = c("black", "blue", "green", "red", "orange"),
    lty = c(1, 2, 2, 2, 1),
    lwd = c(2, 1, 1, 1, 2)
  )
  
  save_current_plot(paste(module_name, var_base, sep = "_"))
}

# -----------------------------
# PLOTTING
# -----------------------------
par(mgp = c(2, 0.7, 0))

reservoir_params <- c("WLEV", "INFLOW", "THRUF")
powerplant_params <- c("THRUF", "PROD")

for (p in reservoir_params) {
  plot_param(fossvatn_res_id, "Fossvatn reservoir", p)
}

for (p in powerplant_params) {
  plot_param(fossvatn_plant_id, "Fossvatn power plant", p)
}

for (p in reservoir_params) {
  plot_param(reinoksvatn_res_id, "Reinoksvatn reservoir", p, inflow_source_id = ocean_id)
}

for (p in powerplant_params) {
  plot_param(reinoksvatn_plant_id, "Reinoksvatn power plant", p)
}

# -----------------------------
# ANNUAL PRODUCTION PLOT
# -----------------------------
avg_total_prod <- mean(annual_production$Total_GWh, na.rm = TRUE)

plot(
  annual_production$YEAR,
  annual_production$Total_GWh,
  type = "b",
  pch = 16,
  lwd = 2,
  xlab = "Year",
  ylab = "Annual production (GWh/year)",
  main = paste(bin_name, "| Total annual power production"),
  ylim = c(0, max(annual_production$Total_GWh, na.rm = TRUE) * 1.1)
)

abline(h = avg_total_prod, col = "red", lwd = 2, lty = 2)

legend(
  "topright",
  legend = c(
    "Annual production",
    "Average",
    paste0(round(avg_total_prod, 2), " GWh/year")
  ),
  col = c("black", "red", NA),
  lty = c(1, 2, NA),
  lwd = c(2, 2, NA),
  pch = c(16, NA, NA),
  bty = "n"
)

save_current_plot("Total_annual_power_production")

# -----------------------------
# STORAGE AVAILABILITY
# -----------------------------
energy_threshold_kWh <- 1632054
energy_equivalent <- 0.675 #weighted average 0.675 and 0.623 for SC4B and SC4D

water_threshold_m3 <- energy_threshold_kWh / energy_equivalent
water_threshold_Mm3 <- water_threshold_m3 / 1e6

cat("\n-----------------------------\n")
cat("RESERVOIR STORAGE THRESHOLD\n")
cat("-----------------------------\n")
cat(sprintf("Energy threshold: %.0f kWh\n", energy_threshold_kWh))
cat(sprintf("Energy equivalent: %.3f kWh/m3\n", energy_equivalent))
cat(sprintf("Required water volume: %.2f m3\n", water_threshold_m3))
cat(sprintf("Required water volume: %.3f Mm3\n", water_threshold_Mm3))

u$Combined_Storage_Mm3 <- u[[paste0("STOR_", fossvatn_res_id)]] +
  u[[paste0("STOR_", reinoksvatn_res_id)]]

storage_availability <- data.frame(
  YEAR = years,
  Days_Above_Threshold = NA_real_,
  Percent_Above_Threshold = NA_real_
)

for (i in seq_along(years)) {
  y <- years[i]
  dfy <- u[u$YEAR == y, ]
  
  days_above <- sum(dfy$Combined_Storage_Mm3 >= water_threshold_Mm3, na.rm = TRUE)
  total_days <- nrow(dfy)
  
  storage_availability$Days_Above_Threshold[i] <- days_above
  storage_availability$Percent_Above_Threshold[i] <- 100 * days_above / total_days
}

cat("\n================ STORAGE AVAILABILITY ================\n")
print(storage_availability)

cat(sprintf("\nAverage time above threshold: %.1f %%\n",
            mean(storage_availability$Percent_Above_Threshold, na.rm = TRUE)))

plot(
  storage_availability$YEAR,
  storage_availability$Percent_Above_Threshold,
  type = "b",
  pch = 16,
  lwd = 2,
  xlab = "Year",
  ylab = "Time above threshold (%)",
  main = paste(bin_name, "| Reservoir storage above required energy threshold"),
  ylim = c(0, 100)
)

abline(
  h = mean(storage_availability$Percent_Above_Threshold, na.rm = TRUE),
  col = "red",
  lwd = 2,
  lty = 2
)

avg_storage_security <- mean(
  storage_availability$Percent_Above_Threshold,
  na.rm = TRUE
)

legend(
  "bottomright",
  legend = c(
    "Yearly value",
    "Average",
    paste0("Energy security = ", round(avg_storage_security, 1), " %")
  ),
  col = c("black", "red", NA),
  lty = c(1, 2, NA),
  lwd = c(2, 2, NA),
  pch = c(16, NA, NA),
  bty = "n"
)

save_current_plot("Reservoir_storage_above_threshold")

# -----------------------------
# EXPORT PDF WITH ALL PLOTS
# -----------------------------
pdf(pdf_file, width = 11, height = 8)

for (p in saved_plots) {
  replayPlot(p)
}

dev.off()

# -----------------------------
# EXPORT CSV FILES
# -----------------------------
write.csv(
  u,
  file = file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")),
  row.names = FALSE
)

write.csv(
  results,
  file = file.path(output_dir, paste0(bin_stem, "_water_results.csv")),
  row.names = FALSE
)

write.csv(
  annual_production,
  file = file.path(output_dir, paste0(bin_stem, "_annual_production.csv")),
  row.names = FALSE
)

cat("\n================ EXPORT COMPLETE ================\n")
cat("Files written to:\n")
cat(file.path(output_dir, paste0(bin_stem, "_enmresDump.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_water_results.csv")), "\n")
cat(file.path(output_dir, paste0(bin_stem, "_annual_production.csv")), "\n")
cat(pdf_file, "\n")
cat("PNG plots written to:\n")
cat(plot_dir, "\n")
