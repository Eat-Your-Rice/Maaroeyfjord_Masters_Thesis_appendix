import pandas as pd

# File path
file_path = r"C:\Users\HP\OneDrive - UiT Office 365\Documents\Masteroppgave\Nordmannset.txt"

# Catchment area in km^2
catchment_area = 19.3

# Read file, skipping the first line
df = pd.read_csv(
    file_path,
    skiprows=1,
    sep=r"\s+",
    header=None,
    names=["date", "flow"],
    engine="python"
)

# Convert columns
df["date"] = pd.to_datetime(df["date"], format="%d.%m.%Y", errors="coerce")
df["flow"] = pd.to_numeric(df["flow"], errors="coerce")

# Remove bad rows
df = df.dropna(subset=["date", "flow"]).copy()

# Extract year
df["year"] = df["date"].dt.year

# Filter period 1991–2020
df_period = df[(df["year"] >= 1991) & (df["year"] <= 2020)].copy()

# Mean discharge for the full period
average_flow = df_period["flow"].mean()  # m^3/s

# Specific runoff
specific_runoff = average_flow * 1000 / catchment_area  # l/s/km^2

# Compute annual runoff volume using actual number of daily values per year
seconds_per_day = 86400
annual_volumes = df_period.groupby("year")["flow"].sum() * seconds_per_day  # m^3/year

# Average annual runoff volume for 1991–2020
average_annual_volume = annual_volumes.mean()

print(f"Average discharge 1991–2020: {average_flow:.3f} m^3/s")
print(f"Average specific runoff: {specific_runoff:.2f} l/s/km^2")
print(f"Average annual runoff volume: {average_annual_volume:,.0f} m^3/year")
print(f"Average annual runoff volume: {average_annual_volume / 1e6:.3f} Mm^3/year")